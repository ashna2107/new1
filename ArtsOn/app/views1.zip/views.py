from django.shortcuts import render,redirect,HttpResponse
from.models import *
from django.contrib import messages

# Create your views here.
def index(re):
    return render(re,'index.html')

def about(re):
    return render(re,'about.html')

def gallery(re):
    return render(re,'gallery.html')

def admindance(re):
    data = compdance.objects.all()
    return render(re,'adminpage/admindance.html',{'data': data})

def adminuser(re):
        data = reguser.objects.all()
        return render(re,'adminpage/adminuser.html',{'data': data})


def adminmusic(re):
    data = compmusic.objects.all()
    return render(re, 'adminpage/adminmusic.html', {'data': data})

def ser(re):
    if 'user' in re.session:
        u=reguser.objects.get(username=re.session['user'])
        m=compmusic.objects.filter(status="active")
        d=compdance.objects.filter(status="active")

        return render(re,'ser.html',{'user':u,'music':m,'dance':d})



def pending(re):
    data=compmusic.objects.filter(status="pending")
    return render(re, "pending.html",{'data':data})

def pending1(re,id1):
    compmusic.objects.filter(pk=id1).update(status='active')
    return redirect(pending)

def pending01(re):
    data=compdance.objects.filter(status="pending")
    return render(re, "pending01.html",{'data':data})

def pending02(re,id2):
    compdance.objects.filter(pk=id2).update(status='active')
    return redirect(pending01)
def profile1(request):
    if 'music' in request.session:
        user=compmusic.objects.get(username=request.session['music'])
        return render(request, "profile.html",{'user':user})


def viewdetails(re,dp):
    user=compmusic.objects.get(pk=dp)
    return render(re,"viewdetails.html",{'user':user})

def cprofile(re,dp):
    user=compdance.objects.get(pk=dp)
    return render(re,"viewdetails.html",{'user':user})



def dancepage(re):
    return render(re, "dancepage.html")

def services(re):
    return render(re, "services.html")



def edititem(req,id3):
    if req.method == 'POST':
        name = req.POST['name']
        username = req.POST['username']
        phone = req.POST['phone']
        email = req.POST['email']
        try:
          profile=req.FILES['profile']
          compmusic.objects.filter(pk=id3).update(name=name, username=username, phone=phone, email=email,
                                                  profile=profile)
        except:
          compmusic.objects.filter(pk=id3).update(name=name,username=username,phone=phone,email=email)
        messages.success(req, "successfully updated")
        return redirect(profile1)
def adminhome(re):
    data = compdance.objects.filter(status="pending")
    data1 = compmusic.objects.filter(status="pending")
    return render(re, "adminpage/adminhome.html", {'a': data.count, 'b': data1.count})



def login(request):
    if request.method=='POST':
        username=request.POST['name']
        password=request.POST['password']
        try:
            data=reguser.objects.get(username=username)
            if data.password==password:
                request.session['user']=username
                messages.success(request, "login success")

                return redirect(ser)
            else:
                messages.error(request, "password incorrect")
                return redirect(login)
                # return HttpResponse("password incorrect")
        except Exception:
            try:
                data = compdance.objects.get(username=username)
                if data.password==password :
                    if data.status=="active":

                        request.session['dance'] = username
                        messages.success(request, "login success")

                        return redirect(ser)
                    else:
                        messages.error(request, "waiting for approval")
                        return redirect(login)

                else:
                    messages.error(request, "password incorrect")
                    return redirect(login)
            except Exception:
                try:
                    data = compmusic.objects.get(username=username)
                    if data.password == password:
                        if data.status=="active":
                            request.session['music'] = username
                            messages.success(request, "login success")

                            return redirect(profile1)
                        else:
                            messages.error(request, "waiting for approval")
                            return redirect(login)
                    else:
                        messages.error(request, "password incorrect")
                        return redirect(login)
                except Exception:
                    if username=='admin' and password=='admin':
                        request.session['admin']=username
                        messages.success(request, "login success")
                        return redirect(adminhome)
                    else:
                        messages.info(request, "username incorrect")
                        return redirect(login)
    else:

        return render(request,"login.html")


def logout(re):
    if 'music' in re.session:
        re.session.flush()
    return redirect(login)
# def mabout(re):



def addprojects(request):
        if request.method == 'POST':
            f = compmusic.objects.get(username=request.session['music'])
            a = request.POST['category']
            b = request.POST['client']
            c = request.POST['date']
            d = request.POST['projectdetail']
            e = request.FILES['projectimg']

            data = project.objects.create(category=a, client=b, date=c, projectdetail=d, projectimage=e, mname=f)
            data.save()
            messages.success(request, "successfully added")

        return render(request,'addprojects.html')



def caddprojects(request):
    if request.method == 'POST':
        c = compdance.objects.get(username=request.session['dance'])
        a = request.POST['category']
        b = request.POST['client']
        c = request.POST['date']
        d = request.POST['projectdetail']
        e = request.FILES['projectimg']

        data = project.objects.create(category=a, client=b, date=c, projectdetail=d, projectimage=e, dname=c)
        data.save()
        messages.success(request, "successfully added")

    return render(request, 'addprojects.html')

def display(re):
    return render(re,'display.html')


l = []
def user(request):
    if request.method == 'POST':
            a = request.POST['name']
            b = request.POST['username']
            c = request.POST['phone']
            d = request.POST['email']
            e = request.POST['password']
            try:

                data = reguser.objects.create(name=a, username=b, phone=c, email=d, password=e)
                data.save()

                messages.success(request, "registration sucess")
            except:
                messages.success(request, "username already exists")
                return redirect(user)

            return redirect(login)
    else:


        return render(request, 'registration/user.html')

def danceteam(re):
    if re.method == 'POST':
            a = re.POST['name']
            b = re.POST['username']
            c = re.POST['phone']
            d = re.POST['email']
            e = re.POST['password']
            f=re.FILES['licence']
            try:

                data = compdance.objects.create(name=a, username=b, phone=c, email=d, password=e, license=f,status='pending')
                print(data)
                data.save()
                messages.success(re, "registration success")
            except:
                messages.success(re, "username already exists")
                return redirect(danceteam)

            return redirect(login)
    else:

         return render(re, 'registration/danceteam.html')

def music(re):
    if re.method == 'POST':
            a = re.POST['name']
            b = re.POST['username']
            c = re.POST['phone']
            d = re.POST['email']
            e = re.POST['password']
            f=re.FILES['licence']
            try:

                data = compmusic.objects.create(name=a, username=b, phone=c, email=d, password=e, license=f,status='pending')
                data.save()

                messages.success(re, "registration success")
            except:
                messages.success(re, "username already exists")
                return redirect(music)

            return redirect(login)
    else:

         return render(re, 'registration/music.html')